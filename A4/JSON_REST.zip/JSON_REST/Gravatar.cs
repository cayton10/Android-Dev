﻿using System;
using System.Collections.Generic;
using System.Text;


namespace JSON_REST
{
    public class Gravatar
    {
        public string profileURL { get; set; }

        public string preferredName { get; set; }

        public string givenName { get; set; }

        public string familyName { get; set; }

        public string currentLocation { get; set; }

        public string firstPhoto { get; set; }
    }
}
